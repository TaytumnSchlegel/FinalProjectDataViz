# Shiny App

library(tidyverse)
library(forecast)
library(caTools)
library(earth)
library(randomForest)
library(kernlab)
library(h2o)
library(neuralnet)
library(Metrics)
library(caret)
library(hms)
library(lubridate)
library(ggplot2)
library(png)
library(plotly)
library(shiny)
library(shinydashboard)
library(DT)


# Import Data

caaBB <- read.csv("NCAAgames.csv", stringsAsFactors = TRUE)

# Select Desired Variables
ncaaBB <- ncaaBB %>%
  select(team_name, game_num, opp_pts, w_l, fg, fga, X3p, X3pa, ft, fta, trb, ast, stl, blk, tov, pf)

# Convert Win/Lose column to numeric
ncaaBB <-  ncaaBB %>% mutate(
  w_l = if_else(w_l == "W", true = 1, false = 0)
)

ncaaBB

# Filter for Baylor Basketball
baylorBB <- ncaaBB %>%
  filter(team_name == "Baylor Bears")

baylorBB


## Data Types

str(baylorBB) 
# to see how the variables included are formatted bc of errors encountered




# Split Data

set.seed(123)
sample = sample.split(baylorBB$w_l, SplitRatio = .75)
train = subset(baylorBB, sample == TRUE)
test = subset(baylorBB, sample == FALSE)



# Remove scientific notations
options(scipen = 999)

# Deep Learning Neural Network

# Model
deepModel <- neuralnet(w_l ~ game_num + opp_pts + fg + fga + X3p + X3pa + ft + fta + trb + ast + stl + blk + tov + pf,
                       data = train,
                       hidden = 1)
deepModel

# Visualization
plot(deepModel)

# Prediction
deepPrediction <- predict(deepModel, test)

# Matrix
deepConfusionMatrix <- table(deepPrediction,
                             test$w_l,
                             dnn = c("Prediction", "Actual"))

# Accuracy
deepAccuracy <- round(sum(diag(deepConfusionMatrix))/ sum(deepConfusionMatrix), digits = 14)
cat("DNN Model Accuracy:", deepAccuracy)



# Random Forest Model
forestModel <- randomForest(w_l ~ game_num + opp_pts + fg + fga + X3p + X3pa + ft + fta + trb + ast + stl + blk + tov + pf, data = train, mtry = 14, ntree = 75)
forestModel

plot(forestModel)

# Prediction
forestPrediction <- predict(forestModel, test, type = "class")
forestPrediction

# Matrix
forestMatrix <- table(forestPrediction,
                      test$w_l,
                      dnn = c("Prediction", "Actual"))

# Accuracy
forestAccuracy <- round(sum(diag(forestMatrix))/ sum(forestMatrix))
cat("Random Forest Accuracy:", forestAccuracy)



#SVM

SVMmodel <- ksvm(w_l ~ game_num + opp_pts + fg + fga + X3p + X3pa + ft + fta + trb + ast + stl + blk + tov + pf,
                 data = train,
                 kernel = "vanilladot")
SVMmodel


# Prediction
SVMprediction <- predict(SVMmodel, test)

# Generate Confusion Matrix
SVMMatrix <- table(SVMprediction,
                   test$w_l,
                   dnn = c("Prediction", "Actual"))

# Accuracy
SVMAccuracy <- round(sum(diag(SVMMatrix))/ sum(SVMMatrix), digits = 4)
cat("SMV Accuracy:", SVMAccuracy)


# AutoML
localH2O = h2o.init()

# Convert to H2O Data
amlBaylorBB <- as.h2o(baylorBB)

# Data Split
amlSplit <- h2o.splitFrame(data = amlBaylorBB, ratios = c(.75))
amlTrain <- amlSplit[[1]]
amlTestValidation <- amlSplit[[2]]

testValidationSplit <- h2o.splitFrame(data = amlTestValidation, ratios = c(.75))
amlTest <- testValidationSplit[[1]]
amlValidation <- testValidationSplit[[2]]

# AutoML
autoMLModel <- h2o.automl(y = "w_l",
                          x = c("game_num", "opp_pts", "fg", "fga", "X3p", "X3pa", "ft", "fta", "trb", "ast", "stl", "blk", "tov", "pf"),
                          training_frame = amlTrain,
                          validation_frame = amlValidation,
                          max_runtime_secs = 60,
                          seed = 123)

# Prediction
amlPrediction = h2o.predict(object = autoMLModel, newdata = amlTest)

AutoMLtable <- as.data.frame(h2o.get_leaderboard(object = autoMLModel, extra_columns = 'ALL'))
AutoMLtable


print(h2o.performance(autoMLModel@leader, amlTest))

# Sidebar 
sidebar <- dashboardSidebar(
  sidebarMenu(
    menuItem("Deep Learning Neural Network", tabName = "Deep Learning Neural Network"),
    menuItem("Auto ML", tabName = "Auto ML"),
    menuItem("Random Forest", tabName = "Random Forest"),
    menuItem("SMV", tabName = "SVM")
  )
)


dashboardBody(
  tabItems(
    tabItem(tabName = "Deep Learning Neural Network",
            fluidRow(
              box(
                valueBox(
                  value =  7.308439e-03,
                  subtitle = "Error",
                  color = "red"
                ),
                
                valueBox(
                  value = 0.05714286,
                  subtitle = "Accuracy",
                  color = "green"
                )
              )
            )
    ),
    
    
    tabItem(tabName = "Auto ML",
            h2("Auto ML"),
            dataTableOutput("AutoMLtable")
    )
  )
)
tabItem(tabName = "Random Forest",
        fluidRow(
          box(
            valueBox(
              value = 75,
              subtitle = "Number of Trees",
              color = "gray"
            ),
            
            valueBox(
              value = 14,
              subtitle = "# of Variables Tried at Split",
              color = "gray"
            ),
            valueBox(
              value = 0,
              subtitle = "Accuracy",
              color = "green"
            )
          )
        )
)
tabItem(tabName = "SVM",
        fluidRow(
          valueBox(
            value = 3214, 
            subtitle = "Number of Support Vectors",
            color = "gray"),
          
          valueBox(
            value = 0.476537, 
            Subtitle = "Training error",
            color = "red"),
          
          valueBox(
            value = SVMaccuracy, 
            Subtitle = "Accuracy",
            color = "green")
          
        ))


ui <- fluidPage(
  
  # Dashboard Page
  dashboardPage( 
        dashboardHeader(title = "Baylor Basketball"),
        sidebar,
        body
  )
)


# Define server logic required to draw a histogram
server <- function(input, output) {

  

}


shinyApp(ui = ui, server = server)



